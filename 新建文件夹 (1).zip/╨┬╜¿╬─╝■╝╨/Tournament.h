#pragma once
#include "Player.h"
class Tournament{
public:
	Player* run(Player* competitors[8]);
	string getName() {
		return "Tournament";
	}
};
