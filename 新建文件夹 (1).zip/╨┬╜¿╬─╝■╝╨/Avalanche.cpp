#include "Avalanche.h"
char Avalanche::makeMove() {
	return 'R';
}