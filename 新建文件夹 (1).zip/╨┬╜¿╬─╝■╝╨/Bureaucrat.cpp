#include "Bureaucrat.h"
char Bureaucrat::makeMove() {
	return 'P';
}