#ifndef HUMAN_H
#define HUMAN_H
#include<iostream>
#include<string>
using namespace std;
class Human{
    public:
    Human();
    char makeMove();



};
#endif


