#include "Toolbox.h"
char Toolbox::makeMove() {
	return 'S';
}